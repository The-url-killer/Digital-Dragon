package com.digital_dragon.Digital.Dragon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalDragonApplicationTests {

	@Test
	void contextLoads() {
	}

}

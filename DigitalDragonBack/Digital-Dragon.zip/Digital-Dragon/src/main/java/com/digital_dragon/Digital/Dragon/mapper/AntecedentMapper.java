package com.digital_dragon.Digital.Dragon.mapper;

public class AntecedentMapper {
}

package com.digital_dragon.Digital.Dragon.models.enums;

public enum TypeEquipment {
  ARMOR,
  COMMON,
  WEAPON,
}

package com.digital_dragon.Digital.Dragon.models;

import java.util.List;
import java.util.Map;

public abstract class BaseCharacter {
  private String name;
  private Map<String, Integer> atributes;
  private List<String> expertises;
  private String lore;
}

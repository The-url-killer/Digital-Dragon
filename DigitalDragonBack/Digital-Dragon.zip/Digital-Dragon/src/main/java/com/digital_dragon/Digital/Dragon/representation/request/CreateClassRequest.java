package com.digital_dragon.Digital.Dragon.representation.request;

public class CreateClassRequest {
}
